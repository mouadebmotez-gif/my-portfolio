import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';

export default function Projects() {
  const projects = [
    {
      title: 'TaskMaster Pro',
      description: 'A collaborative task management application designed for agile teams. Features include Kanban boards, real-time updates via WebSockets, role-based access control, and automated progress reporting.',
      image: '/images/project1.jpg',
      tags: ['React', 'Node.js', 'Socket.io', 'MongoDB', 'Tailwind CSS'],
      liveUrl: 'https://taskmaster-demo.vercel.app',
      githubUrl: 'https://github.com/motez/taskmaster'
    },
    {
      title: 'SkyCast Weather',
      description: 'A beautiful, location-aware weather forecasting app. It provides real-time current conditions, hourly forecasts, and severe weather alerts using the OpenWeather API with a highly responsive, animated UI.',
      image: '/images/project2.jpg',
      tags: ['React Native', 'TypeScript', 'OpenWeather API', 'Framer Motion', 'Zustand'],
      liveUrl: 'https://skycast-app.vercel.app',
      githubUrl: 'https://github.com/motez/skycast'
    }
  ];

  return (
    <section id="projects" className="py-24 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold text-white mb-4"
          >
            Featured Projects
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0, width: 0 }}
            whileInView={{ opacity: 1, width: '80px' }}
            viewport={{ once: true }}
            className="h-1 bg-blue-500 rounded-full mb-8"
          ></motion.div>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="max-w-2xl text-lg text-slate-400"
          >
            Here are some of my recent works. Each project was built to solve a specific problem and taught me valuable lessons in architecture and user experience.
          </motion.p>
        </div>

        <div className="space-y-20">
          {projects.map((project, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6 }}
              className={`flex flex-col ${index % 2 !== 0 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-10 items-center`}
            >
              {/* Project Image */}
              <div className="w-full lg:w-1/2 relative group">
                <div className="absolute inset-0 bg-blue-500/20 rounded-2xl transform translate-x-3 translate-y-3 transition-transform group-hover:translate-x-4 group-hover:translate-y-4"></div>
                <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
                  <div className="absolute inset-0 bg-slate-900/40 group-hover:bg-transparent transition-colors duration-300 z-10"></div>
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-auto aspect-video object-cover transform group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
              </div>

              {/* Project Info */}
              <div className={`w-full lg:w-1/2 ${index % 2 !== 0 ? 'lg:pr-12' : 'lg:pl-12'}`}>
                <h3 className="text-2xl font-bold text-white mb-4">{project.title}</h3>
                <div className="bg-slate-900/80 backdrop-blur-sm p-6 rounded-xl border border-slate-800 mb-6 shadow-lg">
                  <p className="text-slate-300 leading-relaxed">
                    {project.description}
                  </p>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-8">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-3 py-1 bg-slate-800 text-blue-400 text-sm font-medium rounded-md border border-slate-700">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-6">
                  <a href={project.githubUrl} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors font-medium">
                    <Github size={20} />
                    <span>Code</span>
                  </a>
                  <a href={project.liveUrl} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors font-medium">
                    <ExternalLink size={20} />
                    <span>Live Demo</span>
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
