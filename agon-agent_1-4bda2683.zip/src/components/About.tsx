import { motion } from 'framer-motion';
import { Code, Layout, Server, Database } from 'lucide-react';

export default function About() {
  const services = [
    {
      icon: <Layout className="text-blue-400" size={28} />,
      title: 'Frontend Development',
      description: 'Building responsive, interactive, and accessible user interfaces using React, Vue, and modern CSS frameworks.'
    },
    {
      icon: <Server className="text-purple-400" size={28} />,
      title: 'Backend Development',
      description: 'Creating robust APIs and server-side logic using Node.js, Express, Python, and scalable architecture.'
    },
    {
      icon: <Database className="text-emerald-400" size={28} />,
      title: 'Database Design',
      description: 'Designing efficient database schemas and managing data with PostgreSQL, MongoDB, and Redis.'
    },
    {
      icon: <Code className="text-orange-400" size={28} />,
      title: 'Clean Architecture',
      description: 'Writing maintainable, testable code following SOLID principles and best practices for long-term project health.'
    }
  ];

  return (
    <section id="about" className="py-24 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold text-white mb-4"
          >
            About Me
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0, width: 0 }}
            whileInView={{ opacity: 1, width: '80px' }}
            viewport={{ once: true }}
            className="h-1 bg-blue-500 mx-auto rounded-full mb-8"
          ></motion.div>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="max-w-3xl mx-auto text-lg text-slate-400"
          >
            I'm a passionate software engineer with a strong foundation in computer science and a love for building products that solve real-world problems. When I'm not coding, you can find me exploring new technologies, contributing to open-source, or enjoying a good cup of coffee.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-800/50 border border-slate-700/50 p-8 rounded-2xl hover:bg-slate-800 transition-colors"
            >
              <div className="w-14 h-14 bg-slate-900 rounded-xl flex items-center justify-center mb-6 shadow-inner">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
              <p className="text-slate-400 leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
