import { motion } from 'framer-motion';
import { ArrowRight, Download } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/images/hero-bg.jpg" 
          alt="Background" 
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/50 via-slate-950/80 to-slate-950"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-medium mb-6">
              Available for new opportunities
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold text-white tracking-tight mb-6 leading-tight">
              Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">Motez</span><br/>
              Full Stack Developer
            </h1>
            <p className="text-lg md:text-xl text-slate-400 mb-8 max-w-lg leading-relaxed">
              I build exceptional and accessible digital experiences for the web. Specializing in React, Node.js, and modern web technologies.
            </p>
            <div className="flex flex-wrap gap-4">
              <a 
                href="#projects" 
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                View My Work
                <ArrowRight size={18} />
              </a>
              <a 
                href="#contact" 
                className="px-8 py-4 bg-transparent border border-slate-700 hover:border-slate-500 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                Download CV
                <Download size={18} />
              </a>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:flex justify-center"
          >
            <div className="relative w-80 h-80 md:w-96 md:h-96">
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-500 blur-3xl opacity-20 animate-pulse"></div>
              <img 
                src="/images/profile.jpg" 
                alt="Motez Mouadeb" 
                className="relative z-10 w-full h-full object-cover rounded-3xl border-2 border-slate-800 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500"
              />
              
              {/* Floating badges */}
              <div className="absolute -top-6 -right-6 z-20 bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl transform -rotate-6">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-white">Open to work</span>
                </div>
              </div>
              
              <div className="absolute -bottom-8 -left-8 z-20 bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xl transform rotate-6">
                <div className="flex items-center gap-3">
                  <div className="text-2xl font-bold text-blue-400">5+</div>
                  <span className="text-sm font-medium text-slate-400 leading-tight">Years<br/>Experience</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
