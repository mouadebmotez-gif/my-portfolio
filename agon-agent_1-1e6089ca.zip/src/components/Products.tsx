import { motion } from 'framer-motion';
import { useState } from 'react';
import { ShoppingBag, Heart, Sparkles } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Baklawa Amande',
    nameAr: 'بقلاوة باللوز',
    description: 'Fine pâte filo croustillante, amandes concassées et sirop de fleur d\'oranger',
    price: '45 DT',
    priceUnit: '/ 500g',
    image: '/images/baklawa.jpg',
    category: 'baklawa',
    badge: 'Best-seller',
  },
  {
    id: 2,
    name: 'Dattes Farcies',
    nameAr: 'تمر محشي',
    description: 'Dattes Deglet Nour fourrées à la pâte d\'amande et enrobées de chocolat',
    price: '38 DT',
    priceUnit: '/ 500g',
    image: '/images/dates.jpg',
    category: 'dates',
    badge: 'Premium',
  },
  {
    id: 3,
    name: 'Assortiment Royal',
    nameAr: 'تشكيلة ملكية',
    description: 'Sélection de nos meilleures pâtisseries traditionnelles tunisiennes',
    price: '65 DT',
    priceUnit: '/ 1kg',
    image: '/images/assortment.jpg',
    category: 'assortment',
    badge: 'Signature',
  },
  {
    id: 4,
    name: 'Coffret Prestige',
    nameAr: 'صندوق برستيج',
    description: 'Élégant coffret cadeau avec assortiment de baklawas et dattes farcies',
    price: '120 DT',
    priceUnit: '/ coffret',
    image: '/images/giftbox.jpg',
    category: 'gift',
    badge: 'Cadeau',
  },
];

const categories = [
  { id: 'all', name: 'Tous' },
  { id: 'baklawa', name: 'Baklawa' },
  { id: 'dates', name: 'Dattes' },
  { id: 'assortment', name: 'Assortiments' },
  { id: 'gift', name: 'Coffrets' },
];

export default function Products() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null);

  const filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(p => p.category === activeCategory);

  return (
    <section id="products" className="relative py-24 lg:py-32 bg-charcoal-950">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, rgba(212, 165, 116, 0.3) 1px, transparent 0)`,
          backgroundSize: '40px 40px',
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 text-gold-500 text-sm tracking-widest uppercase mb-4">
            <Sparkles className="w-4 h-4" />
            Nos Créations
          </span>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-charcoal-100 mb-4">
            L'Excellence <span className="text-gradient-gold">Artisanale</span>
          </h2>
          <p className="font-elegant text-xl text-charcoal-400 italic max-w-2xl mx-auto">
            Chaque création est le fruit d'un savoir-faire transmis de génération en génération
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-6 py-2.5 rounded-full text-sm tracking-wide transition-all duration-300 ${
                activeCategory === cat.id
                  ? 'bg-gold-500 text-charcoal-950 font-medium'
                  : 'bg-charcoal-900/50 text-charcoal-400 hover:text-gold-500 border border-charcoal-800 hover:border-gold-500/30'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              onMouseEnter={() => setHoveredProduct(product.id)}
              onMouseLeave={() => setHoveredProduct(null)}
              className="group relative bg-charcoal-900/30 rounded-2xl overflow-hidden border border-charcoal-800 hover:border-gold-500/30 transition-all duration-500"
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal-950 via-transparent to-transparent" />
                
                {/* Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-gold-500 text-charcoal-950 text-xs font-medium rounded-full">
                    {product.badge}
                  </span>
                </div>

                {/* Quick Actions */}
                <div className={`absolute top-4 right-4 flex flex-col gap-2 transition-all duration-300 ${
                  hoveredProduct === product.id ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                }`}>
                  <button className="p-2 bg-charcoal-950/80 backdrop-blur-sm rounded-full text-charcoal-300 hover:text-gold-500 hover:bg-charcoal-900 transition-colors">
                    <Heart className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="mb-2">
                  <h3 className="font-serif text-xl text-charcoal-100 group-hover:text-gold-500 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-sm text-charcoal-500 font-arabic" dir="rtl">{product.nameAr}</p>
                </div>
                <p className="text-sm text-charcoal-400 mb-4 line-clamp-2">
                  {product.description}
                </p>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xl font-semibold text-gold-500">{product.price}</span>
                    <span className="text-sm text-charcoal-500">{product.priceUnit}</span>
                  </div>
                  <button className="p-3 bg-gold-500 text-charcoal-950 rounded-full hover:bg-gold-400 transition-colors hover:scale-110 transform duration-200">
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="text-center mt-12"
        >
          <a
            href="#order"
            className="inline-flex items-center gap-2 text-gold-500 hover:text-gold-400 transition-colors group"
          >
            <span>Voir tout le catalogue</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
