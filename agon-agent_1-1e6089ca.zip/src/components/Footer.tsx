import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-charcoal-950 border-t border-charcoal-800">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold-500 to-gold-600 flex items-center justify-center">
                <span className="font-serif text-charcoal-950 text-lg font-bold">S</span>
              </div>
              <div>
                <h3 className="font-serif text-lg text-gold-500">SOLTAN</h3>
                <p className="text-[10px] text-charcoal-500 tracking-[0.2em] uppercase">Pâtisserie</p>
              </div>
            </div>
            <p className="text-charcoal-400 text-sm leading-relaxed">
              L'excellence de la pâtisserie tunisienne depuis des générations. Savoir-faire artisanal et ingrédients de qualité.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-medium text-charcoal-100 mb-4">Liens Rapides</h4>
            <ul className="space-y-2">
              {['Accueil', 'Nos Créations', 'Notre Histoire', 'Commander', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '-')}`} className="text-charcoal-400 hover:text-gold-500 transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-medium text-charcoal-100 mb-4">Contact</h4>
            <ul className="space-y-2 text-sm text-charcoal-400">
              <li>
                <a href="tel:+21627055523" className="hover:text-gold-500 transition-colors">
                  +216 27 055 523
                </a>
              </li>
              <li>
                <a href="mailto:contact@soltan.tn" className="hover:text-gold-500 transition-colors">
                  contact@soltan.tn
                </a>
              </li>
              <li>Tunisie</li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-charcoal-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-charcoal-500 text-sm">
            © {new Date().getFullYear()} Pâtisserie SOLTAN. Tous droits réservés.
          </p>
          <p className="text-charcoal-500 text-sm flex items-center gap-1">
            Fait avec <Heart className="w-4 h-4 text-gold-500 fill-gold-500" /> en Tunisie
          </p>
        </div>
      </div>
    </footer>
  );
}
