import { motion } from 'framer-motion';
import { Award, Heart, Leaf, Clock } from 'lucide-react';

const values = [
  {
    icon: Leaf,
    title: 'Ingrédients Naturels',
    description: 'Sélection rigoureuse des meilleurs ingrédients: amandes de qualité, miel pur, fleur d\'oranger',
  },
  {
    icon: Heart,
    title: 'Savoir-Faire Artisanal',
    description: 'Techniques traditionnelles transmises de génération en génération depuis des décennies',
  },
  {
    icon: Award,
    title: 'Excellence & Qualité',
    description: 'Chaque pièce est façonnée avec amour et attention pour une qualité irréprochable',
  },
  {
    icon: Clock,
    title: 'Fraîcheur Garantie',
    description: 'Préparation quotidienne pour vous garantir des pâtisseries toujours fraîches',
  },
];

export default function About() {
  return (
    <section id="about" className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-charcoal-950 via-charcoal-900/50 to-charcoal-950" />
      
      {/* Decorative */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl -translate-y-1/2" />
      <div className="absolute top-1/4 right-0 w-72 h-72 bg-gold-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* Main Image */}
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
              <img
                src="/images/shop-interior.jpg"
                alt="Notre boutique"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-950/60 via-transparent to-transparent" />
            </div>

            {/* Floating Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="absolute -bottom-6 -right-6 bg-charcoal-900/90 backdrop-blur-sm border border-gold-500/20 rounded-xl p-6 shadow-2xl"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center">
                  <span className="font-serif text-2xl text-charcoal-950 font-bold">25+</span>
                </div>
                <div>
                  <p className="text-charcoal-100 font-medium">Années d\'excellence</p>
                  <p className="text-sm text-charcoal-400">au service de vos papilles</p>
                </div>
              </div>
            </motion.div>

            {/* Decorative Frame */}
            <div className="absolute -top-4 -left-4 w-full h-full border-2 border-gold-500/20 rounded-2xl -z-10" />
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-gold-500 text-sm tracking-widest uppercase mb-4 block">
              Notre Histoire
            </span>
            <h2 className="font-serif text-4xl md:text-5xl text-charcoal-100 mb-6">
              Une Passion <span className="text-gradient-gold">Héritée</span>
            </h2>
            <div className="space-y-4 text-charcoal-300 leading-relaxed mb-8">
              <p>
                Fondée au cœur de la Tunisie, <strong className="text-gold-500">Pâtisserie SOLTAN</strong> perpétue l'art ancestral de la pâtisserie tunisienne. Chaque création est le fruit d'un savoir-faire transmis de génération en génération.
              </p>
              <p>
                Notre engagement envers l'excellence nous pousse à sélectionner uniquement les meilleurs ingrédients: amandes fines, miel pur, eau de fleur d'oranger, et les dattes Deglet Nour les plus savoureuses.
              </p>
              <p>
                De nos baklawas croustillants à nos dattes farcies gourmandes, chaque bouchée est une invitation au voyage, une célébration des saveurs authentiques de notre terroir.
              </p>
            </div>

            {/* Values Grid */}
            <div className="grid grid-cols-2 gap-4">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="p-4 bg-charcoal-900/30 border border-charcoal-800 rounded-xl hover:border-gold-500/30 transition-colors group"
                >
                  <value.icon className="w-6 h-6 text-gold-500 mb-2" />
                  <h4 className="font-medium text-charcoal-100 mb-1 group-hover:text-gold-500 transition-colors">
                    {value.title}
                  </h4>
                  <p className="text-sm text-charcoal-400 line-clamp-2">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
