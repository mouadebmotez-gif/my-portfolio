import { motion } from 'framer-motion';
import { ChevronDown, Award, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/assortment.jpg"
          alt="Pâtisseries"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal-950/80 via-charcoal-950/60 to-charcoal-950" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-gold-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="mb-6"
        >n          <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-gold-500/10 border border-gold-500/20 rounded-full text-gold-500 text-sm tracking-wider">
            <Star className="w-4 h-4 fill-gold-500" />
            Depuis des générations
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-medium tracking-tight mb-6"
        >
          <span className="text-charcoal-100">Pâtisserie</span>
          <br />
          <span className="text-gradient-gold">SOLTAN</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="font-elegant text-xl md:text-2xl text-charcoal-300 italic mb-8 max-w-2xl mx-auto"
        >
          L'art de la pâtisserie tunisienne, sublimé avec passion et tradition
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
        >
          <a
            href="#products"
            className="px-8 py-4 bg-gradient-to-r from-gold-500 to-gold-600 text-charcoal-950 font-medium tracking-wide rounded-full hover:shadow-lg hover:shadow-gold-500/30 transition-all duration-300 hover:scale-105"
          >
            Découvrir nos créations
          </a>
          <a
            href="#order"
            className="px-8 py-4 border border-gold-500/30 text-gold-500 font-medium tracking-wide rounded-full hover:bg-gold-500/10 transition-all duration-300"
          >
            Commander en ligne
          </a>
        </motion.div>

        {/* Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="flex items-center justify-center gap-8 text-charcoal-400"
        >
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-gold-500" />
            <span className="text-sm">Qualité Premium</span>
          </div>
          <div className="w-px h-4 bg-charcoal-700" />
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-gold-500 fill-gold-500" />
            <span className="text-sm">100% Naturel</span>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.a
          href="#products"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center gap-2 text-charcoal-500 hover:text-gold-500 transition-colors"
        >
          <span className="text-xs tracking-widest uppercase">Explorer</span>
          <ChevronDown className="w-5 h-5" />
        </motion.a>
      </motion.div>
    </section>
  );
}
