import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="relative py-24 lg:py-32 bg-charcoal-900/30">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(212, 165, 116, 0.4) 1px, transparent 0)`,
            backgroundSize: '30px 30px',
          }} />
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="text-gold-500 text-sm tracking-widest uppercase mb-4 block">
            Contact
          </span>
          <h2 className="font-serif text-4xl md:text-5xl text-charcoal-100 mb-4">
            Restons en <span className="text-gradient-gold">Contact</span>
          </h2>
          <p className="font-elegant text-xl text-charcoal-400 italic">
            Nous serions ravis de vous entendre
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            {/* Info Cards */}
            <div className="grid gap-4">
              {[
                { icon: MapPin, title: 'Adresse', content: 'Tunisie', link: 'https://maps.app.goo.gl/VNkZdcKGbSTLPcW48' },
                { icon: Phone, title: 'Téléphone', content: '+216 27 055 523', link: 'tel:+21627055523' },
                { icon: Mail, title: 'Email', content: 'contact@soltan.tn', link: 'mailto:contact@soltan.tn' },
                { icon: Clock, title: 'Horaires', content: 'Lun - Sam: 8h - 20h | Dim: 9h - 18h' },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-4 p-5 bg-charcoal-900/50 border border-charcoal-800 rounded-xl hover:border-gold-500/30 transition-colors group"
                >
                  <div className="p-3 bg-gold-500/10 rounded-lg">
                    <item.icon className="w-5 h-5 text-gold-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-charcoal-100 mb-1">{item.title}</h4>
                    {item.link ? (
                      <a href={item.link} className="text-charcoal-400 hover:text-gold-500 transition-colors" target="_blank" rel="noopener noreferrer">
                        {item.content}
                      </a>
                    ) : (
                      <p className="text-charcoal-400">{item.content}</p>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Social Links */}
            <div className="flex gap-4">
              <a
                href="#"
                className="p-4 bg-charcoal-900/50 border border-charcoal-800 rounded-xl text-charcoal-400 hover:text-gold-500 hover:border-gold-500/30 transition-all"
              >
                <Facebook className="w-6 h-6" />
              </a>
              <a
                href="#"
                className="p-4 bg-charcoal-900/50 border border-charcoal-800 rounded-xl text-charcoal-400 hover:text-gold-500 hover:border-gold-500/30 transition-all"
              >
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <form className="space-y-6 bg-charcoal-900/50 border border-charcoal-800 rounded-2xl p-8">
              <div>
                <label className="block text-sm text-charcoal-300 mb-2">Nom complet</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-charcoal-950 border border-charcoal-800 rounded-xl text-charcoal-100 placeholder-charcoal-500 focus:outline-none focus:border-gold-500/50 transition-colors"
                  placeholder="Votre nom"
                />
              </div>
              <div>
                <label className="block text-sm text-charcoal-300 mb-2">Email</label>
                <input
                  type="email"
                  className="w-full px-4 py-3 bg-charcoal-950 border border-charcoal-800 rounded-xl text-charcoal-100 placeholder-charcoal-500 focus:outline-none focus:border-gold-500/50 transition-colors"
                  placeholder="votre@email.com"
                />
              </div>
              <div>
                <label className="block text-sm text-charcoal-300 mb-2">Téléphone</label>
                <input
                  type="tel"
                  className="w-full px-4 py-3 bg-charcoal-950 border border-charcoal-800 rounded-xl text-charcoal-100 placeholder-charcoal-500 focus:outline-none focus:border-gold-500/50 transition-colors"
                  placeholder="+216 XX XXX XXX"
                />
              </div>
              <div>
                <label className="block text-sm text-charcoal-300 mb-2">Message</label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-3 bg-charcoal-950 border border-charcoal-800 rounded-xl text-charcoal-100 placeholder-charcoal-500 focus:outline-none focus:border-gold-500/50 transition-colors resize-none"
                  placeholder="Votre message ou commande spéciale..."
                />
              </div>
              <button
                type="submit"
                className="w-full py-4 bg-gradient-to-r from-gold-500 to-gold-600 text-charcoal-950 font-medium rounded-xl hover:shadow-lg hover:shadow-gold-500/30 transition-all duration-300 hover:scale-[1.02]"
              >
                Envoyer le message
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
