import { motion } from 'framer-motion';
import { useState } from 'react';
import { ShoppingBag, Truck, CreditCard, Clock, CheckCircle2, Minus, Plus, X } from 'lucide-react';

const orderItems = [
  { id: 1, name: 'Baklawa Amande', price: 45, unit: '500g' },
  { id: 2, name: 'Baklawa Pistache', price: 55, unit: '500g' },
  { id: 3, name: 'Dattes Farcies Amande', price: 38, unit: '500g' },
  { id: 4, name: 'Dattes Chocolat', price: 42, unit: '500g' },
  { id: 5, name: 'Assortiment Royal', price: 65, unit: '1kg' },
  { id: 6, name: 'Kaak Warka', price: 35, unit: '500g' },
  { id: 7, name: 'Coffret Prestige', price: 120, unit: 'coffret' },
  { id: 8, name: 'Coffret Découverte', price: 85, unit: 'coffret' },
];

interface CartItem {
  id: number;
  name: string;
  price: number;
  unit: string;
  quantity: number;
}

export default function Order() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);

  const addToCart = (item: typeof orderItems[0]) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handlePlaceOrder = () => {
    setOrderPlaced(true);
    setCart([]);
    setTimeout(() => setOrderPlaced(false), 5000);
  };

  return (
    <section id="order" className="relative py-24 lg:py-32 bg-charcoal-900/30">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d4a574' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 text-gold-500 text-sm tracking-widest uppercase mb-4">
            <ShoppingBag className="w-4 h-4" />
            Commande en Ligne
          </span>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-charcoal-100 mb-4">
            Passez <span className="text-gradient-gold">Votre Commande</span>
          </h2>
          <p className="font-elegant text-xl text-charcoal-400 italic max-w-2xl mx-auto">
            Sélectionnez vos pâtisseries favorites et recevez-les chez vous
          </p>
        </motion.div>

        {/* Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
        >
          {[
            { icon: Truck, text: 'Livraison rapide' },
            { icon: CreditCard, text: 'Paiement à la livraison' },
            { icon: Clock, text: 'Préparation fraîche' },
            { icon: CheckCircle2, text: 'Qualité garantie' },
          ].map((benefit, i) => (
            <div key={i} className="flex items-center justify-center gap-2 p-4 bg-charcoal-900/50 border border-charcoal-800 rounded-xl">
              <benefit.icon className="w-5 h-5 text-gold-500" />
              <span className="text-sm text-charcoal-300">{benefit.text}</span>
            </div>
          ))}
        </motion.div>

        {/* Order Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {orderItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center justify-between p-4 bg-charcoal-900/50 border border-charcoal-800 rounded-xl hover:border-gold-500/30 transition-colors group"
            >
              <div>
                <h4 className="font-medium text-charcoal-100 group-hover:text-gold-500 transition-colors">
                  {item.name}
                </h4>
                <p className="text-sm text-charcoal-400">{item.price} DT / {item.unit}</p>
              </div>
              <button
                onClick={() => addToCart(item)}
                className="p-2 bg-gold-500/10 text-gold-500 rounded-lg hover:bg-gold-500 hover:text-charcoal-950 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </motion.div>
          ))}
        </div>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-charcoal-900 border border-gold-500/30 rounded-2xl p-6 mb-8"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-xl text-charcoal-100">Votre Commande</h3>
              <span className="px-3 py-1 bg-gold-500 text-charcoal-950 text-sm rounded-full">
                {totalItems} article{totalItems > 1 ? 's' : ''}
              </span>
            </div>
            <div className="space-y-3 mb-4">
              {cart.map(item => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-charcoal-950/50 rounded-lg">
                  <div className="flex-1">
                    <span className="text-charcoal-100">{item.name}</span>
                    <span className="text-sm text-charcoal-400 ml-2">({item.unit})</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.id, -1)}
                        className="p-1 text-charcoal-400 hover:text-gold-500 transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center text-charcoal-100">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, 1)}
                        className="p-1 text-charcoal-400 hover:text-gold-500 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <span className="text-gold-500 font-medium w-20 text-right">{item.price * item.quantity} DT</span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-1 text-charcoal-500 hover:text-red-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between pt-4 border-t border-charcoal-800">
              <span className="text-lg text-charcoal-300">Total</span>
              <span className="text-2xl font-semibold text-gold-500">{total} DT</span>
            </div>
            <button
              onClick={handlePlaceOrder}
              className="w-full mt-4 py-4 bg-gradient-to-r from-gold-500 to-gold-600 text-charcoal-950 font-medium rounded-xl hover:shadow-lg hover:shadow-gold-500/30 transition-all duration-300 hover:scale-[1.02]"
            >
              Confirmer la commande
            </button>
          </motion.div>
        )}

        {/* Order Success Message */}
        {orderPlaced && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-charcoal-950/80 backdrop-blur-sm"
          >
            <div className="bg-charcoal-900 border border-gold-500/30 rounded-2xl p-8 text-center max-w-md mx-4">
              <div className="w-16 h-16 bg-gold-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-charcoal-950" />
              </div>
              <h3 className="font-serif text-2xl text-charcoal-100 mb-2">Commande Confirmée!</h3>
              <p className="text-charcoal-400 mb-4">
                Merci pour votre commande. Nous vous contacterons bientôt pour confirmer les détails de livraison.
              </p>
              <button
                onClick={() => setOrderPlaced(false)}
                className="px-6 py-2 bg-gold-500 text-charcoal-950 rounded-lg hover:bg-gold-400 transition-colors"
              >
                Fermer
              </button>
            </div>
          </motion.div>
        )}

        {/* Contact Info */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-8"
        >
          <p className="text-charcoal-400">
            Pour les commandes spéciales ou grandes quantités, contactez-nous directement:
          </p>
          <a href="tel:+21627055523" className="text-gold-500 hover:text-gold-400 text-lg font-medium">
            +216 27 055 523
          </a>
        </motion.div>
      </div>
    </section>
  );
}
