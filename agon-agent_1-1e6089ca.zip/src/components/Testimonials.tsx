import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Fatma B.',
    role: 'Cliente fidèle',
    content: 'Les baklawas de SOLTAN sont tout simplement divins! Un goût authentique qui me rappelle ceux de ma grand-mère. La qualité est toujours impeccable.',
    rating: 5,
  },
  {
    name: 'Ahmed M.',
    role: 'Client régulier',
    content: 'J\'ai commandé un coffret prestige pour l\'Aïd et tous mes invités ont été conquis. La présentation était magnifique et les saveurs exceptionnelles.',
    rating: 5,
  },
  {
    name: 'Leila K.',
    role: 'Amoureuse des sweets',
    content: 'Les dattes farcies sont un pur délice! On sent la qualité des ingrédients. C\'est devenu mon adresse préférée pour les pâtisseries tunisiennes.',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-charcoal-950 via-charcoal-900/30 to-charcoal-950" />
      
      {/* Decorative */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gold-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="text-gold-500 text-sm tracking-widest uppercase mb-4 block">
            Témoignages
          </span>
          <h2 className="font-serif text-4xl md:text-5xl text-charcoal-100 mb-4">
            Ce Que Disent <span className="text-gradient-gold">Nos Clients</span>
          </h2>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className="relative bg-charcoal-900/30 border border-charcoal-800 rounded-2xl p-8 hover:border-gold-500/30 transition-colors"
            >
              {/* Quote Icon */}
              <Quote className="absolute top-6 right-6 w-8 h-8 text-gold-500/20" />
              
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-gold-500 fill-gold-500" />
                ))}
              </div>

              {/* Content */}
              <p className="text-charcoal-300 italic mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center">
                  <span className="text-charcoal-950 font-serif font-bold">
                    {testimonial.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-charcoal-100">{testimonial.name}</p>
                  <p className="text-sm text-charcoal-500">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
